# Doporučení pro některé další typy informačních systémů


