# Obecná doporučení k centralizovaným agendovým informačním systémům



