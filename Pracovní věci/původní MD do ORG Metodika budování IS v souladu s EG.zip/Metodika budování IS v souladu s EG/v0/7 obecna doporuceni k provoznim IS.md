# Obecná doporučení pro informační systémy zajišťující obecné schopnosti úřadu
